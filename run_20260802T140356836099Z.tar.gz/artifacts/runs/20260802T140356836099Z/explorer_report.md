# Pipeline Execution Decision Tree

This graph is dynamically generated from actual execution metrics.

```mermaid
flowchart TD
    S_0(["Acquisition | In: 0"])
    Start --> S_0
    S_0 --> E_0(["End Acquisition | Out: 1639"])
    S_1(["Classification | In: 1639"])
    E_0 -->|Output| S_1
    S_1 --> F_0{OBJECTIVELY_INCOMPATIBLE?}
    F_0 -- Yes (50) --> Drop_0[Drop]
    F_0 -- No --> N_0(...Continue)
    N_0 --> F_1{EXPERIENCE_TOO_LOW?}
    F_1 -- Yes (10) --> Drop_1[Drop]
    F_1 -- No --> N_1(...Continue)
    N_1 --> F_2{EXPERIENCE_TOO_HIGH?}
    F_2 -- Yes (35) --> Drop_2[Drop]
    F_2 -- No --> N_2(...Continue)
    N_2 --> F_3{DESC_RED_FLAG?}
    F_3 -- Yes (1) --> Drop_3[Drop]
    F_3 -- No --> N_3(...Continue)
    N_3 --> F_4{NON_SOFTWARE_ROLE?}
    F_4 -- Yes (423) --> Drop_4[Drop]
    F_4 -- No --> N_4(...Continue)
    N_4 --> F_5{DESCRIPTION_DUPLICATE?}
    F_5 -- Yes (19) --> Drop_5[Drop]
    F_5 -- No --> N_5(...Continue)
    N_5 --> E_1(["End Classification | Out: 1101"])
    S_2(["Selection | In: 1101"])
    E_1 -->|Output| S_2
    S_2 --> F_6{JobDeferred?}
    F_6 -- Yes (444) --> Drop_6[Drop]
    F_6 -- No --> N_6(...Continue)
    N_6 --> E_2(["End Selection | Out: 13"])
    S_3(["Application | In: 657"])
    E_2 -->|Output| S_3
    S_3 --> F_7{JobFailed?}
    F_7 -- Yes (7) --> Drop_7[Drop]
    F_7 -- No --> N_7(...Continue)
    N_7 --> F_8{JobRouted?}
    F_8 -- Yes (644) --> Drop_8[Drop]
    F_8 -- No --> N_8(...Continue)
    N_8 --> F_9{JobDeferred?}
    F_9 -- Yes (444) --> Drop_9[Drop]
    F_9 -- No --> N_9(...Continue)
    N_9 --> E_3(["End Application | Out: 0"])
```
